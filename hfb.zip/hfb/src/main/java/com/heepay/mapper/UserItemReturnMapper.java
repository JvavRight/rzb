package com.heepay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heepay.model.UserItemReturn;
import org.springframework.stereotype.Repository;

@Repository
public interface UserItemReturnMapper extends BaseMapper<UserItemReturn> {

}
