import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _33a78a70 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _ed01a7dc = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _3eb965c1 = () => interopDefault(import('..\\pages\\about\\detail.vue' /* webpackChunkName: "pages/about/detail" */))
const _20b27b7d = () => interopDefault(import('..\\pages\\about\\job.vue' /* webpackChunkName: "pages/about/job" */))
const _78fb130e = () => interopDefault(import('..\\pages\\about\\leader.vue' /* webpackChunkName: "pages/about/leader" */))
const _30d648c8 = () => interopDefault(import('..\\pages\\about\\notice.vue' /* webpackChunkName: "pages/about/notice" */))
const _4f5e2b08 = () => interopDefault(import('..\\pages\\about\\partner.vue' /* webpackChunkName: "pages/about/partner" */))
const _490ccbbc = () => interopDefault(import('..\\pages\\about\\policy.vue' /* webpackChunkName: "pages/about/policy" */))
const _3aeca109 = () => interopDefault(import('..\\pages\\about\\price.vue' /* webpackChunkName: "pages/about/price" */))
const _1fdc7f69 = () => interopDefault(import('..\\pages\\about\\profile.vue' /* webpackChunkName: "pages/about/profile" */))
const _20c70db8 = () => interopDefault(import('..\\pages\\about\\report.vue' /* webpackChunkName: "pages/about/report" */))
const _15e6c066 = () => interopDefault(import('..\\pages\\about\\team.vue' /* webpackChunkName: "pages/about/team" */))
const _243e9da4 = () => interopDefault(import('..\\pages\\help.vue' /* webpackChunkName: "pages/help" */))
const _09e2edb4 = () => interopDefault(import('..\\pages\\lend\\index.vue' /* webpackChunkName: "pages/lend/index" */))
const _1d07084c = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _98a0c5e0 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _0d1178b8 = () => interopDefault(import('..\\pages\\user.vue' /* webpackChunkName: "pages/user" */))
const _f1fbc66c = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _3b6bc966 = () => interopDefault(import('..\\pages\\user\\apply.vue' /* webpackChunkName: "pages/user/apply" */))
const _39feac16 = () => interopDefault(import('..\\pages\\user\\bind.vue' /* webpackChunkName: "pages/user/bind" */))
const _ba58aecc = () => interopDefault(import('..\\pages\\user\\borrower.vue' /* webpackChunkName: "pages/user/borrower" */))
const _7de7ef5f = () => interopDefault(import('..\\pages\\user\\recharge.vue' /* webpackChunkName: "pages/user/recharge" */))
const _5f379242 = () => interopDefault(import('..\\pages\\user\\withdraw.vue' /* webpackChunkName: "pages/user/withdraw" */))
const _1ed89d0e = () => interopDefault(import('..\\pages\\lend\\_id.vue' /* webpackChunkName: "pages/lend/_id" */))
const _535f6535 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _33a78a70,
    children: [{
      path: "",
      component: _ed01a7dc,
      name: "about"
    }, {
      path: "detail",
      component: _3eb965c1,
      name: "about-detail"
    }, {
      path: "job",
      component: _20b27b7d,
      name: "about-job"
    }, {
      path: "leader",
      component: _78fb130e,
      name: "about-leader"
    }, {
      path: "notice",
      component: _30d648c8,
      name: "about-notice"
    }, {
      path: "partner",
      component: _4f5e2b08,
      name: "about-partner"
    }, {
      path: "policy",
      component: _490ccbbc,
      name: "about-policy"
    }, {
      path: "price",
      component: _3aeca109,
      name: "about-price"
    }, {
      path: "profile",
      component: _1fdc7f69,
      name: "about-profile"
    }, {
      path: "report",
      component: _20c70db8,
      name: "about-report"
    }, {
      path: "team",
      component: _15e6c066,
      name: "about-team"
    }]
  }, {
    path: "/help",
    component: _243e9da4,
    name: "help"
  }, {
    path: "/lend",
    component: _09e2edb4,
    name: "lend"
  }, {
    path: "/login",
    component: _1d07084c,
    name: "login"
  }, {
    path: "/register",
    component: _98a0c5e0,
    name: "register"
  }, {
    path: "/user",
    component: _0d1178b8,
    children: [{
      path: "",
      component: _f1fbc66c,
      name: "user"
    }, {
      path: "apply",
      component: _3b6bc966,
      name: "user-apply"
    }, {
      path: "bind",
      component: _39feac16,
      name: "user-bind"
    }, {
      path: "borrower",
      component: _ba58aecc,
      name: "user-borrower"
    }, {
      path: "recharge",
      component: _7de7ef5f,
      name: "user-recharge"
    }, {
      path: "withdraw",
      component: _5f379242,
      name: "user-withdraw"
    }]
  }, {
    path: "/lend/:id",
    component: _1ed89d0e,
    name: "lend-id"
  }, {
    path: "/",
    component: _535f6535,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decodeURIComponent(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
