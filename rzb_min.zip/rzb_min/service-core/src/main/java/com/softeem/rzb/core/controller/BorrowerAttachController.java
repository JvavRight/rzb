package com.softeem.rzb.core.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 借款人上传资源表 前端控制器
 * </p>
 *
 * @author min
 * @since 2024-06-27
 */
@RestController
@RequestMapping("/borrowerAttach")
public class BorrowerAttachController {

}

